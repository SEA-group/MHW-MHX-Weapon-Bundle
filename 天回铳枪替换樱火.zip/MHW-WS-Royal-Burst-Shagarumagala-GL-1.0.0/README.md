﻿# MHW Weapon skin mod: Shagaru Magala Gunlance / 天廻龙铳枪

======================Presented by SEA group & 狩技======================

本mod用于替换樱火龙皇家铳枪的外观

安装：
把nativePC复制到
steam/steamapps/common/Monster Hunter World/
里面即可

This mod applies to the Pink Rathian gunlance "Royal Burst"

Installation: 
Copy "nativePC" into "steam/steamapps/common/Monster Hunter World/" and restart the game
